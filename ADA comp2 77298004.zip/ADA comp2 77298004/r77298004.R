install.packages("mice")
library('mice')
install.packages("ranger")
library('ranger')
install.packages("psych")
library(psych)

#****************************read csv files and merge************************************

# Read the training and testing datasets for concrete strength
library(readr)
concrete_strength_test <- read_csv("C:/Users/ravii/Downloads/New folder/concrete_strength_test.csv")
View(concrete_strength_test)#View(concretetrain)  # View the structure of the training dataset
library(readr)
concrete_strength_train <- read_csv("C:/Users/ravii/Downloads/New folder/concrete_strength_train.csv")
View(concrete_strength_train)#View(concretetest)  # View the structure of the testing dataset

# Add an indicator column to distinguish between training and testing datasets
concretetrain$isTrain <- "yes"
concretetest$isTrain <- "no"

# Combine the training and testing datasets into one
concrete_strength_datasets <- rbind(concretetrain, concretetest)
#View(concrete_strength_datasets)  # View the combined dataset
summary(concrete_strength_datasets)  # Summary statistics of the combined dataset
describe(concrete_strength_datasets)  # Descriptive statistics of the combined dataset

# Check for missing values in the concrete_strength_datasets dataframe
is.na(concrete_strength_datasets)
# Summarize the total number of missing values in the dataset
sum(is.na(concrete_strength_datasets))
sum(is.na(concrete_strength_datasets$Cement))

# Calculate the proportion of missing values for each column
miss <- apply(concrete_strength_datasets, 2, 
              function(x) sum(is.na(x)) / nrow(concrete_strength_datasets))
# Calculate the average missingness across all columns
missingness <- mean(miss)
missingness

md.pattern(concrete_strength_datasets)

#Q5
#****************************************data imputation using mice***************************

#data imputaion using mean method
imputed_mean<-mice(data=concrete_strength_datasets,m=1,method="mean",maxit=10)
mean_imputed_dataset<-complete(imputed_mean)
sum(is.na(mean_imputed_dataset))
md.pattern(mean_imputed_dataset)
summary(mean_imputed_dataset)  
describe(mean_imputed_dataset) 

#sum(is.na(rf_imputed_dataset$Cement))

# Create empty data frame to store outliers
outliers <- data.frame()
# Loop through each column
for (i in 1:9) {
  # Calculate quartiles and IQR for each column
  Q1 <- quantile(mean_imputed_dataset[[i]], 0.25)
  Q3 <- quantile(mean_imputed_dataset[[i]], 0.75)
  IQR <- Q3 - Q1
  # Calculate lower and upper bounds for outliers
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  
  # Subset outliers for each column and bind them to the 'outliers' data frame
  outliers <- rbind(outliers, mean_imputed_dataset[mean_imputed_dataset[[i]] < lower_bound | mean_imputed_dataset[[i]] > upper_bound, ])
}
# Remove duplicate rows from the outliers data frame
outliers <- unique(outliers)
outliers
#**********************remove outlier******************************

outlier_removed_dataset <- mean_imputed_dataset[!(rownames(mean_imputed_dataset) %in% rownames(outliers)), ]
describe(outlier_removed_dataset)
summary(outlier_removed_dataset)

View(outlier_removed_dataset)
summary(mean_imputed_dataset)
sum(is.na(mean_imputed_dataset))

cleaned_dataset<-outlier_removed_dataset
str(cleaned_dataset)

#******************************** Q6. Data Modeling
#*******************************KNN
# Remove the last column from the dataset
Knn_dataset <- cleaned_dataset[, -ncol(cleaned_dataset)]

# Load necessary libraries
install.packages("caret")
library(caret)

# Define normalize function
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

# Assuming `cleaned_dataset` is your dataset

# Normalize columns 1 to n-1 (excluding the target variable)
knn_dataset_norm <- as.data.frame(lapply(Knn_dataset[, -ncol(Knn_dataset)], normalize))

# Add the target variable to the normalized dataset
knn_dataset_norm$Strength <- Knn_dataset$Strength

# Split data into features (X) and target variable (y)
X <- knn_dataset_norm[, -ncol(knn_dataset_norm)]  # Features
y <- knn_dataset_norm$Strength  # Target variable

# Split data into training and testing sets (80% training, 20% testing)
set.seed(123)  # For reproducibility
train_index <- createDataPartition(y, p = 0.8, list = FALSE)
X_train <- X[train_index, ]
X_test <- X[-train_index, ]
y_train <- y[train_index]
y_test <- y[-train_index]

# Train KNN regression model using cross-validation (5-fold)
set.seed(123)  # For reproducibility
knn_model <- train(
  x = X_train,                       # Features
  y = y_train,                       # Target variable
  method = "knn",                    # KNN regression method
  trControl = trainControl(method = "cv", number = 5),  # 5-fold cross-validation
  tuneGrid = expand.grid(k = 1:30)   # Search grid for K values from 1 to 30
)

# Get the optimal tuning parameters
best_k <- knn_model$bestTune$k

# Print the optimal k value
cat("Optimal k value:", best_k, "\n")

# Predict on test set
y_pred <- predict(knn_model, newdata = X_test)

# Calculate residuals
residuals <- y_test - y_pred

# Calculate R-squared (R2)
SST <- sum((y_test - mean(y_test))^2)
SSE <- sum(residuals^2)
R_squared <- 1 - SSE / SST

# Calculate Adjusted R-squared
n <- nrow(X_test)
p <- ncol(X_test)
adjusted_R_squared <- 1 - (1 - R_squared) * ((n - 1) / (n - p - 1))

# Calculate Mean Squared Error (MSE)
MSE <- mean(residuals^2)

# Calculate Root Mean Squared Error (RMSE)
RMSE <- sqrt(MSE)

# Calculate Mean Absolute Error (MAE)
MAE <- mean(abs(residuals))

# Print R2, Adjusted R2, MSE, RMSE, and MAE
cat("R-squared:", R_squared, "\n")
cat("Adjusted R-squared:", adjusted_R_squared, "\n")
cat("MSE:", MSE, "\n")
cat("RMSE:", RMSE, "\n")
cat("MAE:", MAE, "\n")

# Plot predicted vs. original values
plot(y_test, y_pred, main = "Predicted vs. Original Values",
     xlab = "Original Values", ylab = "Predicted Values")
abline(0, 1, col = "red")

# Plot residuals
plot(residuals, main = "Residuals Plot", xlab = "Index", ylab = "Residuals")

#*************************Random Forest****************

#checking for any missing values if yes gives true
any(is.na(cleaned_dataset))

install.packages("caret")
library(caret)

# Splitting into train and test
ind <-createDataPartition(cleaned_dataset$Strength, p=0.7, list=F)
train<-cleaned_dataset[ind,]
test<-cleaned_dataset[-ind,]

## Model Development using randomForest function
install.packages("randomForest")
library(randomForest)
library(caret)
cleaned_dataset.rf=randomForest(Strength ~ ., data = train)
cleaned_dataset.rf

plot(cleaned_dataset.rf)

pred <- predict(cleaned_dataset.rf, test)
metrics_rmse = RMSE(pred,test$Strength)
metrics_r2 = R2(pred, test$Strength)
metrics_MAE = MAE(pred, test$Strength)
c(metrics_rmse,metrics_r2,metrics_MAE)

# Calculate Model R2
SST <- sum((test$Strength - mean(test$Strength))^2)
SSE <- sum((test$Strength - pred)^2)
model_r2 <- 1 - SSE / SST

# Calculate Adjusted R2
n <- nrow(test)
p <- ncol(test) - 1  # Number of predictors excluding the intercept
adjusted_r2 <- 1 - (1 - model_r2) * ((n - 1) / (n - p - 1))

# Calculate Mean Squared Error (MSE)
MSE <- mean((test$Strength - pred)^2)

# Calculate Mean Absolute Error (MAE)
MAE <- mean(abs(test$Strength - pred))

# Combine all metrics
metrics <- c(metrics_rmse, metrics_r2, adjusted_r2, MSE, RMSE, MAE)

# Print the performance metrics
metrics

# Plot predicted vs observed 
df <-data.frame(pred=pred, obs=test$Strength)
ggplot(df, aes(x=obs, y=pred))+geom_point()


# Model Optimisation
oob.err = double(9)
test.err = double(9)

for(mtry in 1:9) {
  rf=randomForest(Strength~ ., train, mtry=mtry,ntree=500)
  oob.err[mtry] = rf$mse[500] #Error of all Trees fitted 
  pred<-predict(rf,test) #Predictions on Test Set for each Tree 
  test.err[mtry]= mean( (test$Strength - pred)**2) #Mean Squared Test Error
}

matplot(1:mtry , cbind(oob.err,test.err), pch=19 , col=c("red","blue"),type="b",
        ylab="Mean Squared Error",xlab="Number of Predictors Considered at each Split")
legend("topright",legend=c("Out of Bag Error","Test Error"),pch=19, col=c("red","blue"))

test.err
oob.err


#########
# Residual analysis
pred <- predict(cleaned_dataset.rf, test)
residuals <- test$Strength - pred

plot(x = pred, y = residuals, main = "Residuals vs. Fitted Values", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "red")  # Add a horizontal line at y = 0

qqnorm(residuals)
qqline(residuals)

par(mfrow = c(1, 2))  # Arrange plots in a 2x2 grid
for (col in colnames(test)[-ncol(test)]) {
  plot(x = test[[col]], y = residuals, main = paste("Residuals vs.", col), xlab = col, ylab = "Residuals")
}



# Make predictions on the test set
pred <- predict(cleaned_dataset.rf, test)

# Calculate performance metrics
SST <- sum((test$Strength - mean(test$Strength))^2)
SSE <- sum((test$Strength - pred)^2)
model_r2 <- 1 - SSE / SST

n <- nrow(test)
p <- ncol(test) - 1  # Number of predictors excluding the intercept
adjusted_r2 <- 1 - (1 - model_r2) * ((n - 1) / (n - p - 1))

MSE <- mean((test$Strength - pred)^2)
RMSE <- sqrt(MSE)
MAE <- mean(abs(test$Strength - pred))

# Print the performance metrics
metrics <- c(Model_R2 = model_r2, Adjusted_R2 = adjusted_r2, MSE = MSE, RMSE = RMSE, MAE = MAE)
metrics




#***************************************Decision tree*******************
#Descision Tree Modelling
install.packages("rpart.plot")
library(rpart)
library(caret)
set.seed(123)
index <- createDataPartition(cleaned_dataset$Strength, p = 0.8, list = FALSE)

train <- cleaned_dataset[index, ]
test <- cleaned_dataset[-index, ]

cart_fit <- rpart(Strength ~ . , data = train)
summary(cart_fit)

library(rpart.plot)
rpart.plot(cart_fit)

#model evaluation
filtered_data_pred <- predict(cart_fit,test,type="vector")
#confusionMatrix(data=filtered_data_pred,reference = test$Strength)

# Calculate Root Mean Squared Error (RMSE)
rmse <- sqrt(mean((filtered_data_pred - test$Strength)^2))
print(paste("Root Mean Squared Error (RMSE):", rmse))

plot(test$Strength, filtered_data_pred, main = "Actual vs Predicted Strength",
     xlab = "Actual Strength", ylab = "Predicted Strength")
abline(0, 1, col = "red")  # Add a diagonal line for reference

#modeltuning
cart_fit$cptable
plotcp(cart_fit)

opt_filtered_data<- which.min(cart_fit$cptable[,'xerror'])
cp_filtered_data <- cart_fit$cptable[opt_filtered_data,'CP']
cp_filtered_data

pruned_fit<-prune(cart_fit,cp_filtered_data)
rpart.plot(pruned_fit)

pruned_predict<-predict(pruned_fit,test,type = "vector")
pruned_rmse <- sqrt(mean((pruned_predict - test$Strength)^2))
pruned_rmse


# Calculate Mean Absolute Error (MAE)
mae <- mean(abs(pruned_predict - test$Strength))
print(paste("Mean Absolute Error (MAE) for pruned model:", mae))

# Calculate R-squared (coefficient of determination)
SST <- sum((test$Strength - mean(test$Strength))^2)
SSE <- sum((pruned_predict - test$Strength)^2)
rsquared <- 1 - SSE/SST
print(paste("R-squared (R2) for pruned model:", rsquared))

n <- nrow(test)
p <- ncol(test) - 1  # Number of predictors excluding the intercept
adjusted_R_squared <- 1 - (1 - rsquared) * ((n - 1) / (n - p - 1))

# Print Adjusted R-squared
print(paste("Adjusted R-squared (Adjusted R2) for pruned model:", adjusted_R_squared))

# Calculate Mean Squared Error (MSE)
mse <- mean((test$Strength - pruned_predict)^2)
print(paste("Mean Squared Error (MSE) for pruned model:", mse))

#residual analysis
residuals <- test$Strength - pruned_predict
plot(residuals, main = "Residuals Plot", xlab = "Observation", ylab = "Residuals")
plot(pruned_predict, residuals, main = "Residuals vs Fitted Values", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "red")
qqnorm(residuals)
qqline(residuals)
hist(residuals, prob = TRUE, main = "Histogram of Residuals", xlab = "Residuals")
lines(density(residuals), col = "red")


#original vs predicted plot
# Plot original vs predicted strength
plot(test$Strength, pruned_predict, 
     main = "Original vs Predicted Strength",
     xlab = "Original Strength", 
     ylab = "Predicted Strength")
abline(0, 1, col = "red")  # Add a diagonal line for reference

## testing decision tree model****************
# Test Decision Tree Model
cart_test_pred <- predict(pruned_fit, test)

# Calculate residuals
cart_residuals <- test$Strength - cart_test_pred

# Calculate Root Mean Squared Error (RMSE)
cart_RMSE <- sqrt(mean(cart_residuals^2))

# Calculate R-squared (R2)
cart_SSE <- sum(cart_residuals^2)
cart_R_squared <- 1 - cart_SSE / SST

# Calculate adjusted R-squared
cart_adjusted_R_squared <- 1 - (1 - cart_R_squared) * (n - 1) / (n - p - 1)

# Calculate mean squared error (MSE)
cart_MSE <- mean(cart_residuals^2)

# Calculate mean absolute error (MAE)
cart_MAE <- mean(abs(cart_residuals))

# Print performance metrics for Decision Tree
cat("Decision Tree Test Performance Metrics:\n")
cat("RMSE:", cart_RMSE, "\n")
cat("R-squared:", cart_R_squared, "\n")
cat("Adjusted R-squared:", cart_adjusted_R_squared, "\n")
cat("Mean Squared Error (MSE):", cart_MSE, "\n")
cat("Mean Absolute Error (MAE):", cart_MAE, "\n\n")




#**************************************logistic**********************

#logistic regression
library(mlbench)
library(pROC)
library(caret)

train_data <- cleaned_dataset[cleaned_dataset$isTrain == "yes", ]
test_data <- cleaned_dataset[cleaned_dataset$isTrain == "no", ]
library(mlbench)

#considering the threshold of high and low strength

q1 <- quantile(train_data$Strength, 0.25)
q3 <- quantile(train_data$Strength, 0.75)
print(q3)


filtered_df <- train_data[train_data$Strength < q3 | train_data$Strength > q1, ]
#View(filtered_df)


filtered_df$Strength <- ifelse(filtered_df$Strength > q3, 1, 0)


datasets_for_regression = filtered_df
datasets_for_regression$Strength = filtered_df$Strength

data_to_be_trained = datasets_for_regression
#View(datasets_for_regression)

# Assign filtered Strength values to datasets_for_regression



# Fit logistic regression model
logit <- glm(Strength ~ Cement, family = binomial, data = datasets_for_regression)
summary(logit)

library(tidyverse)
# Create dataset for plotting
train2 <- mutate(datasets_for_regression, prob = ifelse(Strength == 1, 1, 0))

# Plot logistic regression model
ggplot(train2, aes(Cement, prob)) +
  geom_point(alpha = 0.2) +
  geom_smooth(method = "glm", method.args = list(family = "binomial")) +
  labs(
    title = "Logistic Regression Model",
    x = "Cement Concentration",
    y = "Probability of High Strength"
  )



#checking the probability for test data
newdata <- data.frame(Cement = test_data$Cement)
probabilities <- predict(logit, newdata, type = "response")
probabilities


# Load required libraries
library(pROC)

# Compute predicted probabilities for the test data
#newdata <- data.frame(Cement = test_data$Cement)
#probabilities <- predict(logit, newdata, type = "response")

# Create a ROC curve object
roc_obj <- roc(ifelse(test_data$Strength > q3, 1, 0), probabilities)

# Plot the ROC curve
plot(roc_obj, main = "ROC Curve", col = "blue")

# Compute the AUC
auc_result <- auc(roc_obj)
print(paste("AUC:", auc_result))

# Residual plot
plot(logit, which = 1, col = "blue", main = "Residual Plot")

# Original vs. Predicted plot
# Original vs. Predicted plot
predicted <- predict(logit, newdata, type = "response")
original <- ifelse(test_data$Strength > q3, 1, 0)  # Assuming your original dataset contains the Strength column
plot(original ~ predicted, col = "blue", main = "Original vs. Predicted", xlab = "Predicted Probabilities", ylab = "Original Strength")


# Additional evaluation metrics
library(caret)
# Confusion matrix
# Confusion matrix
predicted_classes <- ifelse(predicted > 0.5, 1, 0)
actual_classes <- ifelse(test_data$Strength > q3, 1, 0)
confusionMatrix(table(predicted_classes, actual_classes))


# Accuracy
accuracy <- sum(predicted_classes == actual_classes) / length(predicted_classes)
print(paste("Accuracy:", accuracy))


# Sensitivity and Specificity
conf_matrix <- confusionMatrix(table(predicted_classes, actual_classes))
sensitivity <- conf_matrix$byClass["Sensitivity"]
specificity <- conf_matrix$byClass["Specificity"]
print(paste("Sensitivity:", sensitivity))
print(paste("Specificity:", specificity))


##*****************************Testing on LR****************************************
# Compute predicted probabilities for the test data
newdata <- data.frame(Cement = test_data$Cement)
probabilities <- predict(logit, newdata, type = "response")

# Create a ROC curve object
roc_obj <- roc(ifelse(test_data$Strength > q3, 1, 0), probabilities)

# Plot the ROC curve
plot(roc_obj, main = "ROC Curve", col = "blue")

# Compute the AUC
auc_result <- auc(roc_obj)
print(paste("AUC:", auc_result))

# Residual plot
plot(logit, which = 1, col = "blue", main = "Residual Plot")


# Confusion matrix
predicted_classes <- ifelse(predicted > 0.5, 1, 0)
actual_classes <- ifelse(test_data$Strength > q3, 1, 0)
confusionMatrix(table(predicted_classes, actual_classes))

# Accuracy
accuracy <- sum(predicted_classes == actual_classes) / length(predicted_classes)
print(paste("Accuracy:", accuracy))

# Sensitivity and Specificity
conf_matrix <- confusionMatrix(table(predicted_classes, actual_classes))
sensitivity <- conf_matrix$byClass["Sensitivity"]
specificity <- conf_matrix$byClass["Specificity"]
print(paste("Sensitivity:", sensitivity))
print(paste("Specificity:", specificity))





#*************************************NAIVE BAYES

install.packages("e1071")
install.packages("caret")
library(e1071)
library(caret)
install.packages("pROC")
library(pROC)


nb_cleaned_data <- cleaned_dataset

# Calculate threshold value
threshold_value <- quantile(nb_cleaned_data$Strength, 0.75)

# Create binary outcome variable
nb_cleaned_data$HighStrength <- ifelse(nb_cleaned_data$Strength >= threshold_value, "High", "Low")

set.seed(123)  # For reproducibility
train_index <- createDataPartition(nb_cleaned_data$HighStrength, p = 0.8, list = FALSE)  # 80% train, 20% test
train_data <- nb_cleaned_data[train_index, ]
test_data <- nb_cleaned_data[-train_index, ]


nb_fit

# Generate predicted probabilities for the test set
nb_test_pred_prob <- predict(nb_fit, newdata = test_data, type = "prob")

# Extract predicted probabilities for the "High" class
nb_test_pred_prob_high <- nb_test_pred_prob[, "High"]
#ROC

# Convert HighStrength to factor with levels "Low" and "High"
test_data$HighStrength <- factor(test_data$HighStrength, levels = c("Low", "High"))
# Create ROC curve
roc_obj <- roc(test_data$HighStrength, nb_test_pred_prob[, "High"], levels = c("High", "Low"), direction = "<")

plot(roc_obj, main = "ROC Curve for Naive Bayes Model")
auc_value <- auc(roc_obj)


#*****************************************

# Make predictions on the test set using the trained model
nb_predictions <- predict(nb_fit, newdata = test_data)

# Convert predicted values to factor with levels "Low" and "High"
nb_predictions <- factor(nb_predictions, levels = c("Low", "High"))

# Create confusion matrix
conf_matrix <- confusionMatrix(nb_predictions, test_data$HighStrength)

# Print confusion matrix
print(conf_matrix)

# Plot predicted vs. original values
plot(test_data$Strength, nb_test_pred_prob[, "High"], xlab = "Original Values", ylab = "Predicted Values", main = "Predicted vs. Original Values")
abline(0, 1, col = "red")  # Add a diagonal line for comparison

# Create a table with model performance metrics
performance_table <- data.frame(
  AUC = auc_value,
  Accuracy = conf_matrix$overall["Accuracy"],
  Sensitivity = conf_matrix$byClass["Sensitivity"],
  Specificity = conf_matrix$byClass["Specificity"],
  Balanced_Accuracy = conf_matrix$byClass["Balanced Accuracy"]
)

# Print the performance table
print(performance_table)


#******************Naive Bayes Testing*******************

# Make predictions on the test set using the trained model
nb_predictions <- predict(nb_fit, newdata = test_data)

# Convert predicted values to factor with levels "Low" and "High"
nb_predictions <- factor(nb_predictions, levels = c("Low", "High"))

# Create confusion matrix
conf_matrix <- confusionMatrix(nb_predictions, test_data$HighStrength)

# Print confusion matrix
print(conf_matrix)

# Create a ROC curve object
roc_obj <- roc(ifelse(test_data$HighStrength == "High", 1, 0), nb_test_pred_prob_high)

# Plot the ROC curve
plot(roc_obj, main = "ROC Curve for Naive Bayes Model")
auc_value <- auc(roc_obj)

# Create a table with model performance metrics
performance_table <- data.frame(
  AUC = auc_value,
  Accuracy = conf_matrix$overall["Accuracy"],
  Sensitivity = conf_matrix$byClass["Sensitivity"],
  Specificity = conf_matrix$byClass["Specificity"],
  Balanced_Accuracy = conf_matrix$byClass["Balanced Accuracy"]
)

# Print the performance table
print(performance_table)

## testing the model ***********************
# Test KNN Model
knn_test_pred <- predict(knn_model, newdata = X_test)

# Calculate residuals
knn_residuals <- y_test - knn_test_pred

# Calculate Root Mean Squared Error (RMSE)
knn_RMSE <- sqrt(mean(knn_residuals^2))

# Calculate R-squared (R2)
knn_SSE <- sum(knn_residuals^2)
knn_R_squared <- 1 - knn_SSE / SST

# Calculate adjusted R-squared
knn_adjusted_R_squared <- 1 - (1 - knn_R_squared) * (n - 1) / (n - p - 1)

# Calculate mean squared error (MSE)
knn_MSE <- mean(knn_residuals^2)

# Calculate mean absolute error (MAE)
knn_MAE <- mean(abs(knn_residuals))

# Print performance metrics for KNN
cat("KNN Test Performance Metrics:\n")
cat("RMSE:", knn_RMSE, "\n")
cat("R-squared:", knn_R_squared, "\n")
cat("Adjusted R-squared:", knn_adjusted_R_squared, "\n")
cat("Mean Squared Error (MSE):", knn_MSE, "\n")
cat("Mean Absolute Error (MAE):", knn_MAE, "\n\n")








library(readr)
library("psych")
concretetrain <- read_csv("C:/Users/ravii/Downloads/concrete_strength_train.csv")
View(concretetrain)
concretetest <- read_csv("C:/Users/ravii/Downloads/concrete_strength_test.csv")
View(concretetest)


#combining data
concretetrain$isTrain<-"yes"
concretetest$isTrain<-"no"

concrete_strength_all<- rbind(concretetrain, concretetest)


#describing the stats

describe(concrete_strength_all)


#histogram
# Histogram of Concrete Compressive Strength

hist(concrete_strength_all$Strength, main = "Histogram of Concrete Compressive Strength", xlab = "Compressive Strength (MPa)", ylab = "Frequency")
# Scatter plot of Cement vs. Compressive Strength

plot(concrete_strength_all$Cement, concrete_strength_all$Strength, 
     main = "Scatter plot of Cement vs. Compressive Strength",
     xlab = "Cement (kg/m3)", ylab = "Compressive Strength (MPa)")
# Correlation matrix
correlation_matrix <- cor(concrete_strength_all[, -ncol(concrete_strength_all)])
print(correlation_matrix)
library("ranger")


#Extraction of pc_scores
pc_scores<-as.data.frame(concrete_strength_pca$x)
dim(pc_scores)
# Perform PCA (Principal Component Analysis) after imputation
library("mice")
imputed_rf <- mice(data=concrete_strength_all,m=1,method="rf",maxit=10)
completed_imputation_rf <- complete(imputed_rf)
concrete_matrix <- as.matrix(completed_imputation_rf[1:9])
concrete_strength_pca <- prcomp(concrete_matrix)
summary(concrete_strength_pca)

#Extraction of pc_scores
pc_scores<-as.data.frame(concrete_strength_pca$x)
dim(pc_scores)

library('ggplot2')
ggplot(pc_scores, aes(x = PC1, y = PC2)) +
  geom_point()

#Exploring correlation
loadings<-concrete_strength_pca$rotation
loadings

#Extract the loadings for the first PC
loadings<-concrete_strength_pca$rotation[,1]
loadings<-abs(loadings)
#sort PCA in the decreasing order
loadings<-sort(loadings,decreasing = T)
loadings
#select 4 top names of the original variables based on the highest weights
top4<-names(loadings[1:4])
concrete_strength_pca$rotation[top4, 1]

#Extract the loadings for the second PC
loadings2<-concrete_strength_pca$rotation[,2]
loadings2<-abs(loadings2)
loadings2<-sort(loadings2,decreasing = T)
loadings2
top4_2<-names(loadings2[1:4])
concrete_strength_pca$rotation[top4_2, 2]


top_cs<-unique(c(top4, top4_2))
pc_loadings <-as.data.frame(concrete_strength_pca$rotation[top_cs,1:2])

#Plot the relation in ggplo2

pc_loadings$Cement<-rownames(pc_loadings)
ggplot(pc_loadings) +
  geom_segment(aes(x = 0, y = 0, xend = PC1, yend = PC2),
               arrow = arrow(length = unit(0.1, "in")),
               col = "brown") +
  geom_text(aes(x = PC1, y = PC2, label = Cement),
            nudge_y = 0.005, size = 3) +
  scale_x_continuous(expand = c(0.02, 0.02))

# QUESTION Descriptive statistics
mean_cement <- mean(completed_imputation_rf$Cement)
median_cement <- median(completed_imputation_rf$Cement)
sd_cement <- sd(completed_imputation_rf$Cement)

# Print descriptive statistics
cat("Mean Cement:", mean_cement, "\n")
cat("Median Cement:", median_cement, "\n")
cat("Standard Deviation Cement:", sd_cement, "\n")

# Example: Frequency table of Age
table(completed_imputation_rf$Age)

# Descriptive statistics for numeric variables
numeric_vars <- sapply(completed_imputation_rf[, -ncol(completed_imputation_rf)], is.numeric)
numeric_summary <- summary(completed_imputation_rf[, numeric_vars])
print(numeric_summary)

#data visualution more

# Histogram of numeric variables
histograms <- lapply(completed_imputation_rf[, c("Cement", "Blast.Furnace.Slag", "Fly.Ash", 
                                                 "Water", "Superplasticizer", "Coarse.Aggregate", 
                                                 "Fine.Aggregate", "Age", "Strength")],
                     function(x) ggplot(data = completed_imputation_rf, aes(x = x)) +
                       geom_histogram(fill = "skyblue", color = "black", bins = 30) +
                       labs(title = paste("Histogram of", names(x))) +
                       theme_minimal())
# Scatter plot matrix for numeric variables
scatter_matrix <- ggplot(data = completed_imputation_rf, aes(x = Cement, y = Strength)) +
  geom_point() +
  labs(title = "Scatter plot: Cement vs. Strength")

boxplot <- ggplot(data = completed_imputation_rf, aes(x = factor(Age), y = Strength)) +
  geom_boxplot(fill = "skyblue", color = "black") +
  labs(title = "Boxplot of Strength by Age group", x = "Age group", y = "Strength (MPa)")
# Combine plots into a grid
install.packages("gridExtra")
library(gridExtra)


grid.arrange(histograms[[1]], histograms[[2]], histograms[[3]], histograms[[4]], histograms[[5]], 
             histograms[[6]], histograms[[7]], histograms[[8]], histograms[[9]], scatter_matrix, 
             boxplot, ncol = 2)

# Correlation heatmap of numeric variables
correlation_matrix <- cor(completed_imputation_rf[, c("Cement", "Blast.Furnace.Slag", "Fly.Ash", 
                                                      "Water", "Superplasticizer", "Coarse.Aggregate", 
                                                      "Fine.Aggregate", "Age", "Strength")])
heatmap <- ggplot(data = as.data.frame(correlation_matrix), aes(x = Var1, y = Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "steelblue") +
  labs(title = "Correlation Heatmap of Numeric Variables")

faceted_scatter <- ggplot(completed_imputation_rf, aes(x = Cement, y = Water, color = as.factor(isTrain))) +
  geom_point() +
  facet_wrap(~ as.factor(isTrain)) +
  labs(title = "Faceted Scatter Plot: Cement vs Water by isTrain", x = "Cement", y = "Water", color = "isTrain")
print(faceted_scatter)

density_plot_cement <- ggplot(completed_imputation_rf, aes(x = Cement)) +
  geom_density(fill = "skyblue") +
  labs(title = "Density Plot of Cement", x = "Cement", y = "Density")
print(density_plot_cement)

# data preprocessing
library(mice)
print(nrow(concrete_strength_all))
#View(concrete_strength_datasets)
summary(concrete_strength_all)

#finding average sum of na in all columns in percentage
na_in_all_cols = apply(concrete_strength_all,2,function(x)  (sum(is.na(x)))/nrow(concrete_strength_all))
average_na_percentage_in_data = mean(na_in_all_cols)*100
print(average_na_percentage_in_data)

# as the percentage of na in overall data is more than 3.8% that's why imputation is required

md.pattern(concrete_strength_all)

#ncol(concrete_strength_all)

par(mfrow=c(2, 5))
lapply(names(concrete_strength_all), function(col) {
  hist(concrete_strength_all[[col]], main=col, xlab=col, col="skyblue", border="white")
})
#as seen in the graph of histogram the distribution is not normal distribution
#so rf(random forest) is used as a method for imputation

imputed_median <- mice(data=concrete_strength_all,m=1,method="rf",maxit=10)
completed_imputation_rf <- complete(imputed_median)
View(completed_imputation_rf)
sum_ofNa_afterImputaion <- sum(is.na(completed_imputation_rf))
print(sum_ofNa_afterImputaion)

md.pattern(completed_imputation_rf)

#Finding outliers for the given data

#box plot after imputation
for(i in 1:9){
  boxplot(completed_imputation_rf[i],col="red",main="Box Plot",xlab=colnames(completed_imputation_rf)[[i]])
}

#***********************outlier IQR******************

# Create empty data frame to store outliers
# Initialize an empty data frame to store outliers
outliers_data_frame <- data.frame()

# Loop through each column
total_col <- ncol(completed_imputation_rf)

# Initialize an empty data frame to store outliers
outliers_data_frame <- data.frame()

# Loop through each column
for (i in 1:total_col) {
  # Ensure column is numeric before proceeding with calculations
  if(is.numeric(completed_imputation_rf[[i]])) {
    # Calculate quartiles and IQR for each column
    Q1 <- quantile(completed_imputation_rf[[i]], 0.25, na.rm = TRUE)
    Q3 <- quantile(completed_imputation_rf[[i]], 0.75, na.rm = TRUE)
    IQR <- IQR(completed_imputation_rf[[i]], na.rm = TRUE)
    
    # Calculate lower and upper bounds for outliers
    lower_whisker <- Q1 - 1.5 * IQR
    upper_whisker <- Q3 + 1.5 * IQR
    
    # Find outliers for current column
    current_outliers <- completed_imputation_rf[completed_imputation_rf[[i]] < lower_whisker | completed_imputation_rf[[i]] > upper_whisker, ]
    
    # Bind outliers to the outliers_data_frame
    outliers_data_frame <- rbind(outliers_data_frame, current_outliers)
  } else {
    # If the column is not numeric, print a warning message
    warning(paste("Column", i, "is not numeric. Skipping outlier detection for this column."))
  }
}

# Print or do further processing with outliers_data_frame
print(outliers_data_frame)


# Remove duplicate rows from the outliers data frame
outliers <- unique(outliers_data_frame)
outliers
#**********************remove out******************************
data_without_outliers <- completed_imputation_rf[!(rownames(completed_imputation_rf) %in% rownames(outliers)), ]
View(data_without_outliers)

summary(completed_imputation_rf)
summary(data_without_outliers)

#crorelation
strenthVariable<-data_without_outliers[9]

concrete_without_strength<-data_without_outliers[c(1:7)] 

correlated_with_strength<-cor(strenthVariable,concrete_without_strength)

legend <- colnames(data_without_outliers)[-8][-8]


par(mfrow=c(1,1))
barplot(correlated_with_strength,beside = TRUE,col=c("red","yellow","green","violet","orange","blue","pink"),xlab="Concrete Data",names=legend,ylim=c(-0.6,0.6))

#investigate variables

# Calculate variance for numeric variables
variances_for_one_variable <- apply(data_without_outliers[, sapply(data_without_outliers, is.numeric)], 2, var)
variances_for_one_variable


# Calculate the overall variance of numeric variables
total_variance <- sum(variances_for_one_variable)

# Set a threshold as a percentage of total variance (e.g., 5%)
threshold <- 0.05 * total_variance

# Identify variables with low variance (e.g., variance less than a threshold)
low_variance_vars <- names(variances_for_one_variable[variances_for_one_variable < threshold])
low_variance_vars

# Check for constant variables

constant_vars <- sapply(data_without_outliers, function(x) length(unique(x))) == 1
constant_vars <- names(data_without_outliers[constant_vars])

# Combine low variance and constant variables to remove
noise_vars <- c(low_variance_vars, constant_vars)
noise_vars

# Remove noise-increasing variables from your dataset
data_without_noise <- data_without_outliers[, !(names(data_without_outliers) %in% noise_vars)]
data_without_noise

#After Scaling
# Select numeric columns
numeric_cols <- sapply(data_without_outliers, is.numeric)

# Scale numeric data
datascaling <- scale(data_without_outliers[, numeric_cols], center = TRUE, scale = TRUE)
datascaling
# Create an empty plot
par(mfrow = c(2,5))  # Set the layout to 3x3
# Plot histograms of scaled data
for (i in 1:ncol(datascaling)) {
  hist(datascaling[, i], main = colnames(datascaling)[i], xlab = "Scaled Value")
}

